

%% parameters

x0=10;
beta=0.5;
alpha=1;
sigma=1;
% stochastic P(k)=gamma^k
gamma=0.3; 
% gamma=0.7


V=3;
T=20;

% Hessian

% define hessian (constant)
H = zeros(T,T);
H(1,1) = alpha+2*beta; H(1,2) = -beta;
H(T,T) = alpha+beta; H(T,T-1) = -beta;

for k = 2:T-1
    H(k,k-1) = -beta;
    H(k,k) = alpha+2*beta;
    H(k,k+1) = -beta;
end

% compute strong convexity factor and smooth factor
mu = min(eig(H));
L = max(eig(H));

rho=1-mu/(4*L);
% monte-carlo to compute expected regret

K_mc=200;


W_afhc=T;
EReg_rhig=zeros(T,1);
EReg_afhc=zeros(T,1);
EReg_rhig0=0;
EReg_chc=zeros(T,1);
EReg_mpc=zeros(T,1);

for iter_mc=1:K_mc % MC to computed expected regret
    
    
    
    
    %% generate theta by Wiener process
    
    theta=zeros(T,1); % true theta
    theta_pred=zeros(T, T);  % theta_pred(t|s)= prediction of theta_t at time s, note: at time s, predict s-1 is accurate
    theta_pred0=zeros(T,1); % theta_pred(t|0)
    
    
    
    innov=sigma*randn(T,1); % N(0,sigma^2)
    
    
    Pk=zeros(T,1);
    Pk(1)=1;
    
    for k=1:T
        Pk(k)=(gamma)^(k-1);
    end
  
    theta_pred0=4*sin(0.5*[1:T])'; 
    
    % true  theta
    theta=theta_pred0;
    for t=1:T
        
        for s=1:t
            theta(t)=theta(t)+innov(s)*Pk(t-s+1);
        end
        
    end
    
    
    % prediction
    for t=1:T
        for tau=1:t-1
            theta_pred(t,tau)=theta_pred0(t);
            for s=1:tau
                theta_pred(t,tau)=theta_pred(t,tau)+innov(s)*Pk(t-s+1);
            end
        end
    end
    
    
    
    
    
    
    
    
    
    %% optimal cost
    
    
    %
    initial=zeros(T,1);
    initial(1)=beta*x0;
    RHS=alpha*theta+initial;
    %
    xopt=H\RHS;
    
    
    
    Copt=Opt_C(theta, T, x0, alpha, beta);
    
    
    %% RHIG
    
    W1=T;
    
    eta=1/(alpha+2*beta);  % stepsize
    
    Crhig=zeros(W1,1);
    
    for W=1:W1
        
        xrhig=zeros(T,W+1); % store x_t(0)... x_t(W)
        
        xrhig(1,1)=x0;
        
        
        xi=1/(alpha);
        
        for t=2-W:0  % in this part, all prediction we used are from theta_pred0 because t<=0
            % Step 1: initialize x_{t+W}(0) by current prediction of theta_{t+W|0}
            theta_pred_cur=theta_pred0(t+W-1); % this is because when s<=0, prediction is theta(t|s)=theta(t|0)
            
            xrhig(t+W,1)= xrhig(t+W-1,1)-xi*alpha*(xrhig(t+W-1,1)-theta_pred_cur);
            % Step 2: update xt+W-1(1)..., x1(t+W-1)
            for s=t+W-1:-1:1
                k=t+W-s+1; % t+W
                theta_pred_cur=theta_pred0(s);
                
                
                if s-1==0
                    xpre=x0;
                else
                    xpre=xrhig(s-1,k-1);
                end
                
                
                xcur=xrhig(s,k-1);
                
                if s+1>T
                    flag =0;
                    xnex=xcur;
                else
                    flag=1;
                    xnex=xrhig(s+1,k-1);
                end
                
                
                
                xrhig(s,k)= xcur-eta* g_t(xpre, xcur, xnex, theta_pred_cur,flag,alpha,beta);
            end
            
        end
        
        
        
        for t=1:T-W
            
            % Step 1: initialize xt+W(0)
            if t>1
                theta_pred_cur=theta_pred(t+W-1,t-1);
            else
                theta_pred_cur=theta_pred0(t+W-1);
            end
            
            xrhig(t+W,1)=xrhig(t+W-1,1)-xi*alpha*(xrhig(t+W-1,1)-theta_pred_cur);
            
            % Step 2: update xt+W-1,...,xt
            for s=t+W-1:-1:t
                k=t+W-s+1;
                if t>1
                    theta_pred_cur=theta_pred(s,t-1);
                else
                    theta_pred_cur=theta_pred0(s);
                end
                if s-1==0
                    xpre=x0;
                else
                    xpre=xrhig(s-1,k-1);
                end
                
                
                xcur=xrhig(s,k-1);
                
                if s+1>T
                    flag =0;
                    xnex=xcur;
                else
                    flag=1;
                    xnex=xrhig(s+1,k-1);
                end
                
                
                
                xrhig(s,k)= xcur-eta* g_t(xpre, xcur, xnex, theta_pred_cur,flag,alpha,beta);
            end
        end
        
        
        for t=T-W+1:T
            % Step 2: update xT...,xt
            for s=T:-1:t
                k=t+W-s+1;
                if t>1
                    theta_pred_cur=theta_pred(s,t-1);
                else
                    theta_pred_cur=theta_pred0(s);
                end
                if s-1==0
                    xpre=x0;
                else
                    xpre=xrhig(s-1,k-1);
                end
                
                
                xcur=xrhig(s,k-1);
                
                if s+1>T
                    flag =0;
                    xnex=xcur;
                else
                    flag=1;
                    xnex=xrhig(s+1,k-1);
                end
                
                
                
                xrhig(s,k)= xcur-eta* g_t(xpre, xcur, xnex, theta_pred_cur,flag,alpha,beta);
            end
        end
        Crhig(W)=C_T(xrhig(:,W+1), theta,T,x0,alpha, beta);
        
    end
    
    Regret_rhig=Crhig-Copt;
    EReg_rhig=EReg_rhig+Regret_rhig;
    
    
    
    xrhig0=zeros(T,1);
    for t=1:T
        if t==1
            theta_pred_cur=theta_pred0(t);
        else
            theta_pred_cur=theta_pred(t,t-1);
        end
        xrhig0(t)=theta_pred_cur;
    end
    Crhig0=C_T(xrhig0, theta,T,x0,alpha, beta);
    Regret_rhig0=Crhig0-Copt;
    EReg_rhig0=EReg_rhig0+Regret_rhig0;
    
    
    
    
    %% AFHC
    C_AFHC=zeros(T,1);
    for W=1:W_afhc
        % compute Omega_k
        Omega=cell(W,1); % store Omega_k for k=0,..., W-1
        
        M=floor(T/W);
        remain=T-M*W;
        for k=0:W-1
            if k==0
                k1=W;
            else
                k1=k;
            end
            Omegak=k1-W:W:T;
            Omega{k+1}=Omegak;  % it stores Omega_k at Omega(k+1)
            
           
            
        end
        
        
        xFHC=zeros(T,W);  % xFHC_t^(k), k=0:W-1
        
        
        
        
        for k=0:W-1
            
            % FHC-k
            %k=1;
            
            Omegak=Omega{k+1};
            
            for index=1:length(Omegak)
                
                tau=Omegak(index);
                t_list=tau:1:tau+W-1;
                t_predict=tau-1;
                
                t_start=max(min(t_list),1);
                t_end=min(max(t_list),T);
                t_list_adjust=t_start:t_end;
                
                if length(t_list_adjust)>0
                    
                    
                    t_initial=t_start-1;
                    if t_initial==0
                        x_initial=x0;
                    else
                        x_initial=xFHC(t_initial, k+1);
                    end
                    
                    % generate the predicted theta
                    theta_pred_list=zeros(size(t_list_adjust));
                    if t_predict<=0
                        theta_pre_list=theta_pred0(t_list_adjust);
                        % use theta_pred0
                        % note: need to start at t=1
                    else
                        theta_pre_list=theta_pred(t_list_adjust,t_predict);
                    end
                    
                    % compute x(t_start:t_end)
                    [~, xopt_cur]=Opt_C(theta_pre_list, length(theta_pre_list), x_initial, alpha, beta);
                    xFHC(t_list_adjust,k+1)=xopt_cur;
                end
            end
            
        end
        
        
        xAFHC=sum(xFHC,2)/W;
        C_AFHC(W)=C_T(xAFHC, theta,T,x0,alpha, beta);
        
    end
    Regret_AFHC=C_AFHC-Copt;
    EReg_afhc=EReg_afhc+Regret_AFHC;
    
    
    
    %% CHC
    
    
    
    C_CHC=zeros(T,1);
    Omega=cell(V,1); % store Omega_k for k=0,..., W-1
    
    M=floor(T/V);
    remain=T-M*V;
    for k=0:V-1
        if k==0
            k1=V;
        else
            k1=k;
        end
        Omegak=k1-V:V:T;
        Omega{k+1}=Omegak;
        
    end
    
    for W=1:V-1  % V>W not defined, for illustration, we consider commit min(V,W), so same as AFHC
        C_CHC(W)=C_AFHC(W);
    end
    
    for W=V:T
        % compute Omega_k
        
        
        xFHC=zeros(T,V);  % xFHC_t^(k), k=0:W-1
        
        
        
        
        for k=0:V-1
            
            % FHC-k
            %k=1;
            
            Omegak=Omega{k+1};  % start of each epoch with first one being 1-k
            
            for index=1:length(Omegak)  % in this epoch, solve $W$-stage opt
                
                tau=Omegak(index);
                t_list=tau:1:tau+W-1;
                t_predict=tau-1;
                
                t_start=max(min(t_list),1);
                t_end=min(max(t_list),T);
                t_list_adjust=t_start:t_end;
                
                t_commit_end= min(tau+V-1,T);
                t_commit_list=t_start:t_commit_end;
                
                if length(t_list_adjust)>0
                    
                    
                    t_initial=t_start-1;
                    if t_initial==0
                        x_initial=x0;
                    else
                        x_initial=xFHC(t_initial, k+1);
                    end
                    
                    % generate the predicted theta
                    theta_pred_list=zeros(size(t_list_adjust));
                    if t_predict<=0
                        theta_pre_list=theta_pred0(t_list_adjust);
                        % use theta_pred0
                        % note: need to start at t=1
                    else
                        theta_pre_list=theta_pred(t_list_adjust,t_predict);
                    end
                    
                    % compute x(t_start:t_end)
                    [~, xopt_cur]=Opt_C(theta_pre_list, length(theta_pre_list), x_initial, alpha, beta);
                    xFHC(t_commit_list,k+1)=xopt_cur(1:length(t_commit_list));
                end
            end
            
        end
        
        
        xCHC=sum(xFHC,2)/V;
        C_CHC(W)=C_T(xCHC, theta,T,x0,alpha, beta);
        
    end
    Regret_CHC=C_CHC-Copt;
    EReg_chc=EReg_chc+Regret_CHC;
    
    
    
    
end

EReg_rhig=EReg_rhig/K_mc;
EReg_afhc=EReg_afhc/K_mc;

EReg_chc=EReg_chc/K_mc;


%% figure
%


figure;
p=plot(1:T, EReg_rhig,1:W_afhc, EReg_afhc(1:W_afhc), 1:T, EReg_chc);%,1:T);%, sum(distance_onlineopt)*ones(1,T)*0.5);
legend('RHIG','AFHC','CHC','Location','northeast')%,'Optimal online')
%
xlabel('W');
ylabel('Regret');
p(1).LineWidth = 3;
p(2).LineWidth=3;
  p(3).LineWidth=3;
   

p(1).Marker='o';
p(2).Marker='+';
p(1).MarkerSize = 10;
p(2).MarkerSize = 10;
p(3).MarkerSize = 10;
p(3).Marker='d';
ax = gca; 
ax.FontSize = 30;












%% function definitions


function [cost,xopt] = Opt_C(theta, T, x0, alpha, beta)
% compute the optimal cost

% define hessian (constant)
if T>1
    H = zeros(T,T);
    H(1,1) = alpha+2*beta; H(1,2) = -beta;
    H(T,T) = alpha+beta; H(T,T-1) = -beta;
    
    for k = 2:T-1
        H(k,k-1) = -beta;
        H(k,k) = alpha+2*beta;
        H(k,k+1) = -beta;
    end
    
    
    
    
else
    H=alpha+beta;
end

initial=zeros(T,1);
initial(1)=beta*x0;
RHS=alpha*theta+initial;

xopt=H\RHS;

cost=C_T(xopt, theta,T,x0,alpha,beta);

end


function grad=g_t(xpre, xcur, xnex, thetacur,flag,alpha, beta)
% compute dC_T/d xt=alpha(x-theta_t)+beta(2xt-xt-1-xt+1)
% if flag==1, has xt+1, ow no xt+1

%grad=zeros(size(xcur));
if flag==1 % has xt+1
    
    grad=alpha*(xcur-thetacur)+beta*(2*xcur-xpre-xnex);
else
    % no xt+1
    grad=alpha*(xcur-thetacur)+beta*(xcur-xpre);
end

end



function cost=C_T(x, theta,T,x0,alpha, beta)
% total cost, x, theta are T by 1
fxn =@(xtt, thetatt) 0.5*alpha*(xtt-thetatt)^2;

cost=fxn(x(1),theta(1))+0.5*beta*(x(1)-x0)^2;

for t=2:T
    cost =cost+fxn(x(t),theta(t))+0.5*beta*(x(t)-x(t-1))^2;
end

end



