% quadrotor tracking

%% generate target sequence and prediction

Horizon=10;
Delta_t=0.1; % time step
Time_list=1:Delta_t:Horizon;
T=length(Time_list)-1;



sigma=0.5;
gamma=0.6;

%% generate theta by Wiener process

theta=zeros(T+1,1); % true theta
theta_pred=zeros(T+1, T+1);  % theta_pred(t|s)= prediction of theta_t at time s, note: at time s, predict s-1 is accurate
theta_pred0=zeros(T+1,1); % theta_pred(t|0)


% generate innovation process

innov=sigma*randn(T+1,1); % N(0,sigma^2)


 Pk=zeros(T+1,1);
 Pk(1)=1;


for k=1:T+1
Pk(k)=(gamma)^(k-1);
end


theta_pred0=18*sin(0.2*[1:T+1])'+20; 
theta_pred1=6*sin(0.2*[1:T+1])'+20; % after shock

% true  theta
theta=theta_pred0;
PhaseChange = floor(T/2)+3;
theta(PhaseChange:T+1)=theta_pred1(PhaseChange:T+1);
for t=1:T+1
    
    for s=1:t
        theta(t)=theta(t)+innov(s)*Pk(t-s+1);
    end
        
end


% prediction
for t=1:T+1
    for tau=1:t-1
        if tau< PhaseChange
        theta_pred(t,tau)=theta_pred0(t);
        for s=1:tau
        theta_pred(t,tau)=theta_pred(t,tau)+innov(s)*Pk(t-s+1);
        end
        else
            
            theta_pred(t,tau)=theta_pred1(t);
        for s=1:tau
        theta_pred(t,tau)=theta_pred(t,tau)+innov(s)*Pk(t-s+1);
        end
        end
    end
end



%% Quadrotor parameters
g=9.8;


k1=1;
k2=1;
alpha =1;
beta=0.1*Delta_t^4;  
xi=beta/(k1^2*Delta_t^4);
eta=(g-k2)*Delta_t^2;
x0=20;
x_n1=0;




[Copt, xopt, max_eig]=Opt_C(theta, T, x0,x_n1, alpha, xi, eta);
stepsize=1/max_eig;















%% RHIG

Regret_rhig=zeros(T,1);
EReg_rhig=zeros(T,1);
xrhig_output=zeros(T+1,T);
for W=1:T
K=floor(W/2);
xrhig=zeros(T+1, K+1); % store $x_t(0), ..., x_t(K) for t=1,..,T+1
xrhig(1,1)=x0;






for t=2-W:0  % in this part, all prediction we used are from theta_pred0 because t<=0
    % Step 1: initialize x_{t+W}(0) by current prediction of theta_{t+W|0}
    theta_pred_cur=theta_pred0(t+W-1); % this is because when s<=0, prediction is theta(t|s)=theta(t|0)
    
    xrhig(t+W,1)=theta_pred_cur;
    % Step 2: update xt+W-2(1)..., x1(t+W-2K)
    for s=t+W-2:-2:1
        k=(t+W-s)/2+1; % t+W
        theta_pred_cur=theta_pred0(s);
        
        
        if s==1
            xn1=x0;
            xn2=x_n1;
        elseif s==2
            xn1=xrhig(s-1,k-1);
            xn2=x0;
        else
            xn1=xrhig(s-1,k-1);
            xn2=xrhig(s-2,k-1);
        end
        
        
        
        
        xt=xrhig(s,k-1);
        
        if s<T
            xp1=xrhig(s+1,k-1);
            xp2=xrhig(s+2,k-1);
        elseif s==T
            xp1=xrhig(s+1,k-1);
            xp2=xrhig(s+1,k-1);
        else
            xp1=xt; xp2=xt;
        end
         
           
        
    
        
        xrhig(s,k)= xt-stepsize* g_t(xn2, xn1, xt, xp1, xp2, s, T, alpha, xi, theta_pred_cur, eta);
    end
    
end





for t=1:T+1
    
    if t+W<=T+1
    % Step 1: initialize xt+W(0)
    if t>1
        theta_pred_cur=theta_pred(t+W-1,t-1);
    else
        theta_pred_cur=theta_pred0(t+W-1);
    end
        
    xrhig(t+W,1)=theta_pred_cur;
    end
    
    % Step 2: update xt+W-1,...,xt
    for s=t+W-2:-2:t
        if s<=T+1
        k=(t+W-s)/2+1;
        if t>1
            theta_pred_cur=theta_pred(s,t-1);
        else
            theta_pred_cur=theta_pred0(s);
        end
       
        
        
        if s==1
            xn1=x0;
            xn2=x_n1;
        elseif s==2
            xn1=xrhig(s-1,k-1);
            xn2=x0;
        else
            xn1=xrhig(s-1,k-1);
            xn2=xrhig(s-2,k-1);
        end
        
        
        
        
        xt=xrhig(s,k-1);
        
        if s<T
            xp1=xrhig(s+1,k-1);
            xp2=xrhig(s+2,k-1);
        elseif s==T
            xp1=xrhig(s+1,k-1);
            xp2=xrhig(s+1,k-1);
        else
            xp1=xt; xp2=xt;
        end
         
           
        
        
        xrhig(s,k)= xt-stepsize* g_t(xn2, xn1, xt, xp1, xp2, s, T, alpha, xi, theta_pred_cur, eta);
        end
    end

end
Crhig=C_T(xrhig(:,K+1), theta,T,x0,alpha, xi, eta);
Regret_rhig(W)=Crhig-Copt;
xrhig_output(:,W)=xrhig(:,K+1);
end

%% gradient descent on true theta or theta_pred0

xgd=zeros(T+1, K+1);
xgd(:,1)=theta_pred0;

for k=1:K
    full_grad =zeros(T+1,1);
 for t=1:T+1
     xt=xgd(t,k);
     thetat=theta(t);
     if t==1
         xn1=x0; xn2=x_n1; xp1=xgd(t+1,k); xp2=xgd(t+2,k);
     end
     if t==2
         xn1=xgd(t-1,k); xn2=x0; xp1=xgd(t+1,k); xp2=xgd(t+2,k);
     end
     if t==T
         xn1=xgd(t-1,k); xn2=xgd(t-2,k); xp1=xgd(t+1,k); xp2=xgd(t+1,k);
     end
     if t==T+1
         xn1=xgd(t-1,k); xn2=xgd(t-2,k); xp1=xgd(t,k); xp2=xgd(t,k);
     end
     if t>2 && t<T
         xn1=xgd(t-1,k); xn2=xgd(t-2,k); xp1=xgd(t+1,k); xp2=xgd(t+2,k);
     end
     full_grad(t)=g_t(xn2, xn1, xt, xp1, xp2, t, T, alpha, xi, thetat, eta);
 end
xgd(:,k+1)=xgd(:,k)-stepsize*full_grad;
end

% rescale to meter
theta=theta/20;
xrhig_output=xrhig_output/20;


%% figure


    
    
    figure;
q=plot(Time_list, theta,'-.', Time_list, xrhig_output(:,10),'ro', Time_list, xrhig_output(:,1),'o');
%rgb(34,139,34)
line([Time_list(PhaseChange-1) Time_list(PhaseChange-1)], [0 2],'Color','black','LineStyle','--','LineWidth',3)
ylim([0 2])
xlim([1 Horizon])

 q(1).LineWidth=3;
 q(2).MarkerFaceColor = 'r';

q(3).MarkerEdgeColor=[50/255 205/255 50/255];
     q(3).MarkerFaceColor=[50/255 205/255 50/255];
   
    legend('Target','W=10', 'W=1')
    xlabel('Time (s)')
    ylabel('Altitude (m)')
 ax = gca; % current axes
    ax.FontSize = 30;
    



%% functions
fxn =@(xtt, thetatt) 0.5*alpha*(xtt-thetatt)^2;


function grad=g_t(xn2, xn1, xt, xp1, xp2, t, T, alpha, xi, thetat, eta)
if t<=T-1
    grad=alpha*(xt-thetat)+xi*(xt+xn2-2*xn1+eta)+xi*(xp2+xt-2*xp1+eta)+2*xi*(2*xt-xn1-xp1-eta);
elseif t==T
    grad=alpha*(xt-thetat)+xi*(xt+xn2-2*xn1+eta)+2*xi*(2*xt-xn1-xp1-eta);
else
    grad=alpha*(xt-thetat)+xi*(xt+xn2-2*xn1+eta);
end

end


function cost=C_T(x, theta,T,x0,alpha, xi, eta)
% total cost, x, theta are T by 1
fxn =@(xtt, thetatt) 0.5*alpha*(xtt-thetatt)^2;

cost=fxn(x(1),theta(1))+0.5*xi*(x(2)+x0-x(1)+eta)^2;

for t=2:T
    cost =cost+fxn(x(t),theta(t))+0.5*xi*(x(t+1)+x(t-1)-x(t)+eta)^2;
end
t=T;
cost = cost+ fxn(x(t),theta(t));

end




function [cost, xopt, max_eig]=Opt_C(theta, T, x0,x_n1, alpha, xi, eta)
% optimal decision, optimal cost, minimum eigvalue of Hessian (determines
% stepsize in RHIG)
H=zeros(T+1);

for t=1:T+1
    if t<T
        H(t,t)=alpha+6*xi;
    elseif t==T
        H(t,t)=alpha+5*xi;
    else
        H(t,t)=alpha+xi;
    end
    
    if t+1<=T
        H(t, t+1)=-4*xi;
        H(t,t+2)=xi;
    elseif t+1==T+1
        H(t,t+1)=-2*xi;
    end
    
    if t-1>=1 && t<=T
        H(t,t-1)=-4*xi;
    elseif t==T+1
        H(t,t-1)=-2*xi;
    end
    
    if t-2>=1
        H(t,t-2)=xi;
    end
    
    
    
    
end


RHS=zeros(T+1,1);
for t=1:T+1
    RHS(t)=alpha*theta(t);
    if t==1
        RHS(t)=RHS(t)+4*xi*x0-xi*x_n1;
    end
    if t==2
        RHS(t)=RHS(t)-xi*x0;
    end
    if t==T
        RHS(t)=RHS(t)+eta*xi;
    end
    if t==T+1
        RHS(t)=RHS(t)-eta*xi;
    end
end

max_eig=max(eig(H));

xopt=H\RHS;
cost=C_T(xopt, theta,T,x0,alpha, xi, eta);
end

